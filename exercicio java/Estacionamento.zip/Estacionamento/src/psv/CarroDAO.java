
package psv;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class CarroDAO {

    private Connection con;

    public CarroDAO(Connection con) {
        this.con = con;
    }

    public String inserir(CarroBean carro) {
        if (con == null) {
            return "Sem conexão com o banco.";
        }
        String sql = "INSERT INTO carro (placa, cor, descricao) VALUES (?, ?, ?)";

        try {
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, carro.getPlaca());
            ps.setString(2, carro.getCor());
            ps.setString(3, carro.getDescricao());

            if (ps.executeUpdate() > 0) {
                return "Inserido com sucesso.";
            } else {
                return "Erro ao inserir.";
            }

        } catch (SQLException e) {
            return e.getMessage();
        }
    }

    public String alterar(CarroBean carro) {
        if (con == null) {
            return "Sem conexão com o banco.";
        }
        String sql = "UPDATE carro SET cor = ?, descricao = ? WHERE placa = ?";

        try {
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, carro.getCor());
            ps.setString(2, carro.getDescricao());
            ps.setString(3, carro.getPlaca());

            if (ps.executeUpdate() > 0) {
                return "Alterado com sucesso.";
            } else {
                return "Erro ao alterar.";
            }

        } catch (SQLException e) {
            return e.getMessage();
        }
    }

    public String excluir(CarroBean carro) {
        if (con == null) {
            return "Sem conexão com o banco.";
        }
        String sql = "DELETE FROM carro WHERE placa = ?";

        try {
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, carro.getPlaca());

            if (ps.executeUpdate() > 0) {
                return "Excluído com sucesso.";
            } else {
                return "Erro ao excluir.";
            }

        } catch (SQLException e) {
            return e.getMessage();
        }
    }

    public List<CarroBean> listarTodos() {
        if (con == null) {
            return null;
        }
        String sql = "SELECT * FROM carro";
        List<CarroBean> listaCarro = new ArrayList<>();

        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                CarroBean cb = new CarroBean();

                cb.setPlaca(rs.getString("placa"));
                cb.setCor(rs.getString("cor"));
                cb.setDescricao(rs.getString("descricao"));

                listaCarro.add(cb);
            }

            return listaCarro;

        } catch (SQLException e) {
            return null;
        }
    }
}
