
package psv;

import java.sql.Connection;
import java.util.List;

public class Teste {

    public static void main(String[] args) {

        Connection con = Conexao.abrirConexao();

        if (con != null) {

            CarroDAO cd = new CarroDAO(con);

            List<CarroBean> lista = cd.listarTodos();

            if (lista != null) {
                for (CarroBean carro : lista) {
                    System.out.println("Placa: " + carro.getPlaca());
                    System.out.println("Cor: " + carro.getCor());
                    System.out.println("Descrição: " + carro.getDescricao());
                    System.out.println("--------------------");
                }
            } else {
                System.out.println("Erro ao consultar os carros.");
            }

            Conexao.fecharConexao(con);

        } else {
            System.out.println("Não foi possível conectar ao banco.");
        }
    }
}
