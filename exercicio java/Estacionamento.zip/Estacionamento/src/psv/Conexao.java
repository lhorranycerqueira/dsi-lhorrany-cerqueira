
package psv;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {

    public static Connection abrirConexao() {
        Connection con = null;

        String url = "jdbc:mysql://localhost:3306/estacionamento";
        String usuario = "root";
        String senha = "1234";

        try {
            con = DriverManager.getConnection(url, usuario, senha);
            System.out.println("Conexão aberta.");
        } catch (SQLException e) {
            System.out.println("Erro de conexão: " + e.getMessage());
        }

        return con;
    }

    public static void fecharConexao(Connection con) {
        try {
            if (con != null) {
                con.close();
                System.out.println("Conexão fechada.");
            }
        } catch (SQLException e) {
            System.out.println("Erro ao fechar: " + e.getMessage());
        }
    }
}
